package Controler;

public interface EventMenu {

    public void selected(int index);
}
